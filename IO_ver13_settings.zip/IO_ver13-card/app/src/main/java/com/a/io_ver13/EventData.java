package com.a.io_ver13;

import java.sql.Time;
import java.util.Date;

/**
 * Created by Administrator on 2017/12/27.
 */

public class EventData {
    public int event_id;
    public String event_title;
    public Date event_date;
    public Time event_time;
    public boolean event_if_alarm;
    public String event_note;
}
